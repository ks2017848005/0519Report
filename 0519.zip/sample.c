#include<stdio.h>

int main()
{
	printf("Hello c World\n");

	return 3;
}


